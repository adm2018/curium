Sample configuration files for:

SystemD: curiumd.service
Upstart: curiumd.conf
OpenRC:  curiumd.openrc
         curiumd.openrcconf
CentOS:  curiumd.init
OS X:    org.curium.curiumd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
